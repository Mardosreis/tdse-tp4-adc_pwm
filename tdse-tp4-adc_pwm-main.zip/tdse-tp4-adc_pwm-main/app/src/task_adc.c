/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 * [Resto de la licencia original]
 *
 * @file   : task_adc.c
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes. */
#include "main.h"

/* Demo includes. */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes. */
#include "board.h"
#include "app.h"
#include "task_adc.h"

/********************** macros and definitions *******************************/

/********************** internal data declaration ****************************/

/********************** internal functions declaration ***********************/
HAL_StatusTypeDef ADC_Poll_Read(uint16_t *value);

/********************** internal data definition *****************************/
const char *p_task_adc 		= "Task ADC";

/********************** external data declaration *****************************/

extern ADC_HandleTypeDef hadc1;
// Eliminamos el 'extern shared_data_type shared_data' porque lo recibimos por parámetro

/********************** external functions definition ************************/
void task_adc_init(void *parameters)
{
	// Acá recibimos el puntero a la estructura compartida
	shared_data_type *p_shared_data = (shared_data_type *) parameters;

	/* Print out: Task Initialized */
	LOGGER_LOG("  %s is running - %s\r\n", GET_NAME(task_adc_init), p_task_adc);

	p_shared_data->adc_end_of_conversion = false;
}

void task_adc_update(void *parameters)
{
	// Disparamos la conversión
	HAL_ADC_Start(&hadc1);

	// Acá recibimos el puntero a la estructura compartida
	shared_data_type *p_shared_data = (shared_data_type *) parameters;

	// Esperamos hasta 2ms a que termine la conversión
	if (HAL_ADC_PollForConversion(&hadc1, 2) == HAL_OK) {
	        // Guardamos el valor crudo en la estructura a través del PUNTERO (usamos ->)
	        p_shared_data->adc_value = HAL_ADC_GetValue(&hadc1);
	        // Activamos la bandera de fin de conversión a través del PUNTERO
	        p_shared_data->adc_end_of_conversion = true;
	}
	else {
		// LOGGER_LOG("error\n"); // Lo comento para que no sature la consola si hay ruido
	}
}

// Requests start of conversion, waits until conversion done
// (Esta función la dejó el profe, la mantenemos por las dudas)
HAL_StatusTypeDef ADC_Poll_Read(uint16_t *value) {
	HAL_StatusTypeDef res;

	res=HAL_ADC_Start(&hadc1);
	if ( HAL_OK==res ) {
		res=HAL_ADC_PollForConversion(&hadc1, 0);
		if ( HAL_OK==res ) {
			*value = HAL_ADC_GetValue(&hadc1);
		}
	}
	return res;
}

/********************** end of file ******************************************/
