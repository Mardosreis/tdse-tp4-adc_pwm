/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 * [Resto de la licencia original omitida para ahorrar espacio, dejá la que ya tenés]
 *
 * @file   : app.c
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

/* Project includes. */
#include "main.h"

/* Demo includes. */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes. */
#include "app.h"
#include "board.h"
#include "task_adc.h"
// Si no tenés task_pwm.h, comentalo para que no tire error al compilar.
//#include "task_pwm.h"

/********************** macros and definitions *******************************/

#define G_APP_CNT_INI		0ul
#define G_APP_TICK_CNT_INI	0ul
#define TASK_X_WCET_INI		0ul

typedef struct {
	void (*task_init)(void *);
	void (*task_update)(void *);
	void *parameters;
} task_cfg_t;

typedef struct {
    uint32_t WCET;
} task_dta_t;

/********************** internal data declaration ****************************/

// Instanciamos la estructura compartida para que sea global (solo UNA vez)
shared_data_type shared_data = { .adc_end_of_conversion = false, .adc_value = 0, .pwm_active = 1 };

// Traemos los handlers del hardware creados por el CubeMX
extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3;

const task_cfg_t task_cfg_list[]	= {
		{task_adc_init, task_adc_update, &shared_data},
		// Si task_pwm no está definido, comentalo para que el bucle solo corra task_adc
		//{task_pwm_init,	task_pwm_update, &shared_data},
};

#define TASK_QTY (sizeof(task_cfg_list)/sizeof(task_cfg_t))

/********************** internal functions declaration ***********************/

/********************** internal data definition *****************************/

const char *p_sys	= " Bare Metal - Event-Triggered Systems (ETS)\n";
const char *p_app	= " ADC + PWM\n";

/********************** external data declaration *****************************/

uint32_t g_app_cnt;
uint32_t g_app_time_us;

volatile uint32_t g_app_tick_cnt;
task_dta_t task_dta_list[TASK_QTY];

/********************** external functions definition ************************/

void app_init(void)
{
	uint32_t index;

	/* Print out: Application Initialized */
	LOGGER_LOG("\n");
	LOGGER_LOG("%s is running - Tick [mS] = %lu\r\n", GET_NAME(app_init), HAL_GetTick());

	LOGGER_LOG(p_sys);
	LOGGER_LOG(p_app);

	g_app_cnt = G_APP_CNT_INI;

	/* Print out: Application execution counter */
	LOGGER_LOG(" %s = %lu\n", GET_NAME(g_app_cnt), g_app_cnt);

	/* Go through the task arrays */
	for (index = 0; TASK_QTY > index; index++)
	{
		/* Run task_x_init (Esto ya llama a task_adc_init automáticamente) */
		(*task_cfg_list[index].task_init)(task_cfg_list[index].parameters);

		/* Init variables */
		task_dta_list[index].WCET = TASK_X_WCET_INI;
	}

	// Arrancamos el PWM en el canal 1 del Timer 3 al finalizar el init
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);

	cycle_counter_init();
}

void app_update(void)
{
	uint32_t index;
	uint32_t cycle_counter_time_us;

	/* Check if it's time to run tasks */
	if (G_APP_TICK_CNT_INI < g_app_tick_cnt)
    {
    	g_app_tick_cnt--;

    	/* Update App Counter */
    	g_app_cnt++;
    	g_app_time_us = 0;

		/* Go through the task arrays */
		for (index = 0; TASK_QTY > index; index++)
		{
			cycle_counter_reset();

			/* Run task_x_update (Esto ya llama a task_adc_update automáticamente) */
			(*task_cfg_list[index].task_update)(task_cfg_list[index].parameters);

			cycle_counter_time_us = cycle_counter_time_us();

			/* Update variables */
			g_app_time_us += cycle_counter_time_us;

			if (task_dta_list[index].WCET < cycle_counter_time_us)
			{
				task_dta_list[index].WCET = cycle_counter_time_us;
			}
		}

		// AHORA SÍ: El bucle terminó de correr todas las tareas (incluyendo la del ADC).
		// Revisamos la estructura compartida y actualizamos el hardware del LED.
		if (shared_data.adc_end_of_conversion && shared_data.pwm_active) {

			// Escalamos de 12 bits (ADC: 4095) a 16 bits (PWM ARR: 65535)
			uint32_t nuevo_duty = shared_data.adc_value << 4;

			// Aplicamos el nuevo duty cycle al registro de comparación
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, nuevo_duty);

			// Bajamos la bandera para esperar la próxima conversión
			shared_data.adc_end_of_conversion = false;
		}

		// Descomentar para debuggear si necesitás ver el valor
	LOGGER_LOG("%d,%d\n", shared_data.pwm_active, shared_data.adc_value);
    }
}

void HAL_SYSTICK_Callback(void)
{
	g_app_tick_cnt++;
}
